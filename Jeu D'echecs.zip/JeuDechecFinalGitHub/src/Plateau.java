public class Plateau {
    public static final String RESET= "\u001B[0m";
    public static final String GRIS= "\u001B[90m";

    public static int[][] plateauvide() {
        int[][] plateau = new int[8][8];
        for (int ligne = 0; ligne < 8; ligne++) {
            for (int colonne = 0; colonne < 8; colonne++) {
                plateau[colonne][ligne] = -1;
            }
        }
        return plateau;
    }

    //CASE
    //pionBlanc = 0
    //tourBlanche = 2
    //cavalierBlanc = 4
    //fouBlanc = 6
    //Reineblanche = 8
    //Roiblanc = 10
    //casevide = -1


    public static int[][] remplissagetableau(int[][] plateau) {
        for (int colonne = 0; colonne < 8; colonne++) {
            plateau[colonne][1] = 1;
            plateau[colonne][6] = 0;
        }
        for (int colonne = 0; colonne < 8; colonne+=7) {
            plateau[colonne][0] = 3;
            plateau[colonne][7] = 2;
        }

        for (int colonne = 1; colonne < 7; colonne+=5) {
            plateau[colonne][0] = 5;
            plateau[colonne][7] = 4;
        }

        for (int colonne = 2; colonne < 6; colonne+=3) {
            plateau[colonne][0] = 7;
            plateau[colonne][7] = 6;
        }

        plateau[3][0] = 9;
        plateau[3][7] = 8;
        plateau[4][0] = 11;
        plateau[4][7] = 10;

        return plateau;
    }

    public static void affichePlateau(int[][] plateau){

        for (int ligne = 0; ligne < 8; ligne++) {
            switch (ligne) {
                case 0:
                    System.out.print(RESET+"8 |");
                    break;
                case 1:
                    System.out.print(RESET+"7 |");
                    break;
                case 2:
                    System.out.print(RESET+"6 |");
                    break;
                case 3:
                    System.out.print(RESET+"5 |");
                    break;
                case 4:
                    System.out.print(RESET+"4 |");
                    break;
                case 5:
                    System.out.print(RESET+"3 |");
                    break;
                case 6:
                    System.out.print(RESET+"2 |");
                    break;
                case 7:
                    System.out.print(RESET+"1 |");
                    break;
            }
            for (int colonne = 0; colonne < 8; colonne++) {
                switch (plateau[colonne][ligne]){
                    case 0:
                        System.out.print(RESET+"\t♟");
                        break;
                    case 1:
                        System.out.print(GRIS+"\t♟");
                        break;
                    case 2:
                        System.out.print(RESET+"\t♜");
                        break;
                    case 3:
                        System.out.print(GRIS+"\t♜");
                        break;
                    case 4:
                        System.out.print(RESET+"\t♞");
                        break;
                    case 5:
                        System.out.print(GRIS+"\t♞");
                        break;
                    case 6:
                        System.out.print(RESET+"\t♝");
                        break;
                    case 7:
                        System.out.print(GRIS+"\t♝");
                        break;
                    case 8:
                        System.out.print(RESET+"\t♛");
                        break;
                    case 9:
                        System.out.print(GRIS+"\t♛");
                        break;
                    case 10:
                        System.out.print(RESET+"\t♚");
                        break;
                    case 11:
                        System.out.print(GRIS+"\t♚");
                        break;
                    default:
                        System.out.print(RESET+"\t▱");
                }
            }
            System.out.println();
        } System.out.println("  |\tA \tB \tC \tD \tE \tF \tG \tH");
    }
}
