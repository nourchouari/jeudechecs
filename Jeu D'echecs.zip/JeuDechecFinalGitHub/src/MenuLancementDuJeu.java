import java.util.Scanner;
public class MenuLancementDuJeu{
    public static void menuDemarrage(){
        System.out.println("  ");
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        int choix;
        System.out.println("  ");

        do{
            afficherMenuPrincipal();
            System.out.println("  ");
            choix = Integer.parseInt(sc.nextLine());
            while(choix <1 || choix>4){
                System.out.println("Saisie incorrecte! Veillez saisir une valeur entre 1 et 4.");
                choix = Integer.parseInt(sc.nextLine());
            }
            switch (choix) {
                case 1:
                    afficherReglesDuJeu();
                    break;
                case 2:
                    afficherDebutDePartie();
                    DeroulementPartie.deroulementPartieJoueur();
                    break;
            }
        } while (choix != 3);
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("                Vous avez quitté le programme. À bientôt !          ");
        System.out.println("=================================================================================");
        sc.close();
    }

    public static void afficherReglesDuJeu() {
        System.out.println("=================================================================================");
        System.out.println("                               ♖ RÈGLES DU JEU ♜                                 ");
        System.out.println("=================================================================================");
        System.out.println();
        System.out.println("1️⃣  ✦ **But du jeu**");
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("   Le but est de mettre le roi adverse en échec et mat, c'est-à-dire dans une ");
        System.out.println("   situation où il est attaqué et ne peut pas échapper à la capture.");
        System.out.println();
        System.out.println("2️⃣  ✦ **L'échiquier**");
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("   L'échiquier est un carré de 8x8 cases.");
        System.out.println("   Chaque joueur commence avec une armée de 16 pièces :");
        System.out.println("      ♔  1 roi");
        System.out.println("      ♕  1 dame");
        System.out.println("      ♖  2 tours");
        System.out.println("      ♗  2 fous");
        System.out.println("      ♘  2 cavaliers");
        System.out.println("      ♙  8 pions");
        System.out.println("   L'échiquier est positionné de manière à ce que chaque joueur ait une case claire ");
        System.out.println("   dans le coin en bas à droite.");
        System.out.println();
        System.out.println("3️⃣  ✦ **Déplacement des pièces**");
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("   Chaque pièce a son propre mode de déplacement :");
        System.out.println("      ♔  Roi : Une case dans n'importe quelle direction (horizontal, vertical, diagonal).");
        System.out.println("      ♕  Dame : Un nombre illimité de cases dans toutes les directions.");
        System.out.println("      ♖  Tour : Un nombre illimité de cases horizontalement ou verticalement.");
        System.out.println("      ♗  Fou : Un nombre illimité de cases en diagonale.");
        System.out.println("      ♘  Cavalier : Se déplace en \"L\". Il peut sauter par-dessus d'autres pièces.");
        System.out.println("      ♙  Pion :\n" +
                "         - Avance d'une case (ou deux lors de son premier déplacement).\n" +
                "         - Capture en diagonale.\n" +
                "         - Peut effectuer une prise en passant.");
        System.out.println();
        System.out.println("4️⃣  ✦ **Règles spéciales**");
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("      ♔  Échec : Une pièce menace le roi adverse. Le roi doit sortir de cette situation.");
        System.out.println("      ♔  Échec et mat : Le roi est attaqué et ne peut pas échapper à la capture.");
        System.out.println("      ♖  Roque : Mouvement impliquant le roi et une tour (sous conditions).");
        System.out.println("      ♙  Promotion de pion : Un pion peut être promu en dame, tour, fou ou cavalier.");
        System.out.println();
        System.out.println("5️⃣  ✦ **Fin de la partie**");
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("   🎉 Victoire : Par échec et mat ou abandon de l'adversaire.");
        System.out.println("   🤝 Nulle : Plusieurs cas mènent à l'égalité, par exemple :");
        System.out.println("      - Pat : Aucun coup légal possible mais le roi n'est pas en échec.");
        System.out.println("      - Insuffisance de matériel (ex : roi contre roi).");
        System.out.println("      - Règle des 50 coups sans capture ni déplacement de pion.");
        System.out.println("      - Répétition de position trois fois.");
        System.out.println();
        System.out.println("=================================================================================");
        System.out.println();
    }

    public static void afficherMenuPrincipal() {
        System.out.println("=================================================================================");
        System.out.println("                       ♔ BIENVENUE SUR LE JEU D'ÉCHEC ♚  ");
        System.out.println("=================================================================================");
        System.out.println();
        System.out.println("                        By Nour Chouari & Anis Bourmatte     ");
        System.out.println();
        System.out.println("                    Choisissez un numéro pour accéder à l'option :");
        System.out.println();
        System.out.println("                    1. 📜 Afficher les règles du jeu");
        System.out.println("                    2. 🤝 Jouer en 1V1 avec un ami");
        System.out.println("                    3. ❌ Quitter");
        System.out.println();
        System.out.println("=================================================================================");
    }

    public static void afficherDebutDePartie() {
        System.out.println("=================================================================================");
        System.out.println("                               ♚ CHESS GAME ♔           ");
        System.out.println("=================================================================================");
        System.out.println();
        System.out.println("                        Préparez-vous pour une partie !");
        System.out.println();
        System.out.println("                     ♚♛♜♝♞♟  Blancs VS Noirs  ♙♘♗♖♕♔");
        System.out.println();
        System.out.println("                       Les Blancs commencent en premier.");
        System.out.println("                        Bonne chance aux deux joueurs !");
        System.out.println();
        System.out.println("=================================================================================");
        System.out.println(" ");
    }

    public static void afficherFinDePartieEchec(String gagnant) {
        System.out.println("=================================================================================");
        System.out.println("                               ⚔️ FIN DE LA PARTIE ⚔️           ");
        System.out.println("=================================================================================");
        System.out.println();
        System.out.println("                   ♔♕♖♗♘♙ Bravo a " + gagnant + " ! ♙♘♗♖♕♔");
        System.out.println();
        System.out.println("                    Le roi de l'adversaire est en échec et mat.");
        System.out.println();
        System.out.println("=================================================================================");
        System.out.println("                        Merci d'avoir joué à notre jeu !");
        System.out.println("=================================================================================");
    }

}
