import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DeplacementPiece {

    /**
     * -
     * @param plateau
     * @param colonneD
     * @param ligneD
     * @param colonneA
     * @param ligneA
     * @return
     */
    public static List<int[]> trajetCoordonnees(int[][] plateau, int colonneD, int ligneD, int colonneA, int ligneA) {
        List<int[]> trajet = new ArrayList<>();
        // Vérification d'une ligne horizontale
        if (ligneA == ligneD) {
            int step = (colonneA > colonneD) ? 1 : -1;
            for (int i = colonneD + step; i != colonneA; i += step) {
                trajet.add(new int[]{ligneD, i});
                if (!verifCaseVide(plateau, i, ligneD)) {
                    return trajet; // Renvoie les cases parcourues avant la case non vide
                }
            }
        }
        // Vérification d'une colonne verticale
        else if (colonneA == colonneD) {
            int step = (ligneA > ligneD) ? 1 : -1;
            for (int i = ligneD + step; i != ligneA; i += step) {
                trajet.add(new int[]{i, colonneD});
                if (!verifCaseVide(plateau, colonneD, i)) {
                    return trajet; // Renvoie les cases parcourues avant la case non vide
                }
            }
        }
        // Vérification d'une diagonale
        else if (Math.abs(colonneA - colonneD) == Math.abs(ligneA - ligneD)) {
            int stepColonne = (colonneA > colonneD) ? 1 : -1;
            int stepLigne = (ligneA > ligneD) ? 1 : -1;

            int col = colonneD + stepColonne;
            int ligne = ligneD + stepLigne;

            while (col != colonneA && ligne != ligneA) {
                trajet.add(new int[]{ligne, col});
                if (!verifCaseVide(plateau, col, ligne)) {
                    return trajet; // Renvoie les cases parcourues avant la case non vide
                }
                col += stepColonne;
                ligne += stepLigne;
            }
        }
        // Renvoie la liste complète si toutes les cases sont vides
        return trajet;
    }

    /**
     * Verifie que la case d'arrivée est vide pour que la pièce puisse se déplacer
     * @param plateau
     * @param colonneA colonne d'arrivée après le deplacement
     * @param ligneA ligne d'arrivée après le deplacement
     * @return vraie si la case d'arrivée est vide (-1) / faux sinon
     */
    public static boolean verifCaseVide(int plateau[][], int colonneA, int ligneA) { // plateau[colonneA][ligneA]
        if (plateau[colonneA][ligneA] == -1) {
            return true;
        }
        return false;
    }

    /**
     * Vérifie que toutes les cases se trouvant entre la case de départ et la case d'arrivée sont vides (-1)
     * @param plateau
     * @param colonneD colonne de départ avant le deplacement
     * @param ligneD ligne de départ avant le deplacement
     * @param colonneA colonne d'arrivée après le deplacement
     * @param ligneA ligne d'arrivée après le deplacement
     * @return faux si une des cases n'est pas vides / vrai si toutes les cases sont vides (-1)
     */
    public static boolean verifTrajetVide(int[][] plateau, int colonneD, int ligneD, int colonneA, int ligneA) {
        // Vérification d'une ligne horizontale
        if (ligneA == ligneD) {
            int step = (colonneA > colonneD) ? 1 : -1;
            for (int i = colonneD + step; i != colonneA; i += step) {
                if (!verifCaseVide(plateau, i, ligneD)) {
                    return false;
                }
            }
            return true;
        }
        // Vérification d'une colonne verticale
        if (colonneA == colonneD) {
            int step = (ligneA > ligneD) ? 1 : -1;
            for (int i = ligneD + step; i != ligneA; i += step) {
                if (!verifCaseVide(plateau, colonneD, i)) {
                    return false;
                }
            }
            return true;
        }
        // Vérification d'une diagonale
        if (Math.abs(colonneA - colonneD) == Math.abs(ligneA - ligneD)) {
            int stepColonne = (colonneA > colonneD) ? 1 : -1;
            int stepLigne = (ligneA > ligneD) ? 1 : -1;

            int col = colonneD + stepColonne;
            int ligne = ligneD + stepLigne;

            while (col != colonneA && ligne != ligneA) {
                if (!verifCaseVide(plateau, col, ligne)) {
                    return false;
                }
                col += stepColonne;
                ligne += stepLigne;
            }
            return true;
        }
        // Si le déplacement n'est ni une ligne, colonne ou diagonale
        return false;
    }

    /**
     * Vérifie que la position saisie est bien dans le plateau
     * @param colonne de la position saisie
     * @param ligne de la position saisie
     * @return vrai si la position se trouve bien dans le plateau / faux sinon
     */
    public static boolean verifPosition(int colonne, int ligne) {
        if (colonne < 0 || colonne > 7 || ligne < 0 || ligne > 7) {
            return false;
        }
        return true;
    }

    /**
     * Vérifie si le mouvement du pion blanc est bien valide
     * @param colonneDepart  colonne de départ avant le deplacement
     * @param ligneDepart  ligne de départ avant le deplacement
     * @param colonneArrivee colonne d'arrivée après le deplacement
     * @param ligneArrivee ligne d'arrivée après le deplacement
     * @param plateau
     * @return vrai si le déplacement du pion blanc est légal / faux sinon
     */
    public static boolean verifMouvPionBlanc(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {

        //le pion blanc avance d'une case en avant
        if (verifCaseVide(plateau, colonneArrivee, ligneArrivee) == true && ligneArrivee == ligneDepart - 1
                && colonneArrivee == colonneDepart && verifPosition(colonneArrivee, ligneArrivee)) {
            return true;
        }
        //le pion blanc mange une pièce sur la diagonale droite ou gauche
        if (verifCaseVide(plateau, colonneArrivee, ligneArrivee) == false && ligneArrivee == ligneDepart - 1
                && (colonneArrivee == colonneDepart - 1 || colonneArrivee == colonneDepart + 1)
                && verifPosition(colonneArrivee, ligneArrivee) && plateau[colonneArrivee][ligneArrivee] % 2 != plateau[colonneDepart][ligneDepart] % 2) {
            return true;
        }
        //le pion blanc avance de deux cases en avant lors de son premier déplacement
        if (verifCaseVide(plateau, colonneArrivee, ligneArrivee) && ligneDepart == 6
                && ligneArrivee == ligneDepart - 2 && colonneArrivee == colonneDepart && verifPosition(colonneArrivee, ligneArrivee)) {
            return true;
        }
        return false;
    }

    /**
     * Vérifie si le mouvement du pion noir est bien valide
     * @param colonneDepart  colonne de départ avant le deplacement
     * @param ligneDepart  ligne de départ avant le deplacement
     * @param colonneArrivee colonne d'arrivée après le deplacement
     * @param ligneArrivee ligne d'arrivée après le deplacement
     * @param plateau
     * @return vrai si le déplacement du pion noir est légal / faux sinon
     */
    public static boolean verifMouvPionNoir(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        //le pion noir avance d'une case en avant
        if (verifCaseVide(plateau, colonneArrivee, ligneArrivee) == true
                && ligneArrivee == ligneDepart + 1 && colonneArrivee == colonneDepart && verifPosition(colonneArrivee, ligneArrivee)) {
            return true;
        }
        //le pion noir mange une pièce sur la diagonale droite ou gauche
        if (verifCaseVide(plateau, colonneArrivee, ligneArrivee) == false && ligneArrivee == ligneDepart + 1
                && (colonneArrivee == colonneDepart - 1 || colonneArrivee == colonneDepart + 1)
                && verifPosition(colonneArrivee, ligneArrivee) && plateau[colonneArrivee][ligneArrivee] % 2 != plateau[colonneDepart][ligneDepart] % 2) {
            return true;
        }
        //le pion noir avance de deux cases en avant lors de son premier déplacement
        if (verifCaseVide(plateau, colonneArrivee, ligneArrivee) && ligneDepart == 1
                && ligneArrivee == ligneDepart + 2 && colonneArrivee == colonneDepart && verifPosition(colonneArrivee, ligneArrivee)) {
            return true;
        }
        return false;
    }

    /**
     * Vérifie si le mouvement de la tour blanche est bien valide
     * @param colonneDepart  colonne de départ avant le deplacement
     * @param ligneDepart  ligne de départ avant le deplacement
     * @param colonneArrivee colonne d'arrivée après le deplacement
     * @param ligneArrivee ligne d'arrivée après le deplacement
     * @param plateau
     * @return vrai si le déplacement de la tour blanche est légal / faux sinon
     */
    public static boolean verifMouvTourBlanche(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if ((ligneArrivee == ligneDepart || colonneArrivee == colonneDepart) && verifTrajetVide(plateau, colonneDepart, ligneDepart, colonneArrivee, ligneArrivee)
                && verifPosition(colonneArrivee, ligneArrivee) && (plateau[colonneArrivee][ligneArrivee] % 2 != plateau[colonneDepart][ligneDepart] % 2
                || plateau[colonneArrivee][ligneArrivee] == -1)) {
            return true;
        }
        return false;
    }

    /**
     * Vérifie si le mouvement de la tour noire est bien valide
     * @param colonneDepart  colonne de départ avant le deplacement
     * @param ligneDepart  ligne de départ avant le deplacement
     * @param colonneArrivee colonne d'arrivée après le deplacement
     * @param ligneArrivee ligne d'arrivée après le deplacement
     * @param plateau
     * @return vrai si le déplacement de la tour noire est légal / faux sinon
     */
    public static boolean verifMouvTourNoir(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if ((ligneArrivee == ligneDepart || colonneArrivee == colonneDepart) && verifTrajetVide(plateau, colonneDepart, ligneDepart, colonneArrivee, ligneArrivee)
                && verifPosition(colonneArrivee, ligneArrivee) && (plateau[colonneArrivee][ligneArrivee] % 2 != plateau[colonneDepart][ligneDepart] % 2
                || plateau[colonneArrivee][ligneArrivee] == -1)) {
            return true;
        }
        return false;
    }

    /**
     * Vérifie si le mouvement du cavalier est bien valide
     * @param colonneDepart  colonne de départ avant le deplacement
     * @param ligneDepart  ligne de départ avant le deplacement
     * @param colonneArrivee colonne d'arrivée après le deplacement
     * @param ligneArrivee ligne d'arrivée après le deplacement
     * @param plateau
     * @return vrai si le déplacement du cavalier est légal / faux sinon
     */
    public static boolean verifMouvCavalier(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if (verifPosition(colonneArrivee, ligneArrivee) && (plateau[colonneArrivee][ligneArrivee] % 2 != plateau[colonneDepart][ligneDepart] % 2
                || plateau[colonneArrivee][ligneArrivee] == -1) && ((Math.abs(colonneArrivee - colonneDepart) == 2 && Math.abs(ligneArrivee - ligneDepart) == 1)
                || (Math.abs(colonneArrivee - colonneDepart) == 1 && Math.abs(ligneArrivee - ligneDepart) == 2))
                && plateau[colonneDepart][ligneDepart] != plateau[colonneArrivee][ligneArrivee]) {
            return true;
        }
        return false;
    }


    /**
     * Vérifie si le mouvement du fou est bien valide
     * @param colonneDepart  colonne de départ avant le deplacement
     * @param ligneDepart  ligne de départ avant le deplacement
     * @param colonneArrivee colonne d'arrivée après le deplacement
     * @param ligneArrivee ligne d'arrivée après le deplacement
     * @param plateau
     * @return vrai si le déplacement du fou est légal / faux sinon
     */
    public static boolean verifMouvFou(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if (verifPosition(colonneArrivee, ligneArrivee) && (plateau[colonneArrivee][ligneArrivee] % 2 != plateau[colonneDepart][ligneDepart] % 2
                || plateau[colonneArrivee][ligneArrivee] == -1) && verifTrajetVide(plateau, colonneDepart, ligneDepart, colonneArrivee, ligneArrivee)) {
            if (Math.abs(ligneArrivee - ligneDepart) == Math.abs(colonneArrivee - colonneDepart)) return true;
        }
        return false;
    }

    /**
     * Vérifie si le mouvement de la reine est bien valide
     * @param colonneDepart  colonne de départ avant le deplacement
     * @param ligneDepart  ligne de départ avant le deplacement
     * @param colonneArrivee colonne d'arrivée après le deplacement
     * @param ligneArrivee ligne d'arrivée après le deplacement
     * @param plateau
     * @return vrai si le déplacement de la reine est légal / faux sinon
     */
    public static boolean verifMouvReine(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if (verifPosition(colonneArrivee, ligneArrivee) && (plateau[colonneArrivee][ligneArrivee] % 2 != plateau[colonneDepart][ligneDepart] % 2
                || plateau[colonneArrivee][ligneArrivee] == -1) && verifTrajetVide(plateau, colonneDepart, ligneDepart, colonneArrivee, ligneArrivee)) {
            if ((ligneArrivee == ligneDepart || colonneArrivee == colonneDepart) || Math.abs(ligneArrivee - ligneDepart) == Math.abs(colonneArrivee - colonneDepart)) {
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * Vérifie si le mouvement du roi est bien valide
     * @param colonneDepart  colonne de départ avant le deplacement
     * @param ligneDepart  ligne de départ avant le deplacement
     * @param colonneArrivee colonne d'arrivée après le deplacement
     * @param ligneArrivee ligne d'arrivée après le deplacement
     * @param plateau
     * @return vrai si le déplacement du roi est légal / faux sinon
     */
    public static boolean verifMouvRoi(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if (verifPosition(colonneArrivee, ligneArrivee) && (plateau[colonneArrivee][ligneArrivee] % 2 != plateau[colonneDepart][ligneDepart] % 2
                || plateau[colonneArrivee][ligneArrivee] == -1)) {
            if ((ligneArrivee == ligneDepart + 1 && (colonneArrivee == colonneDepart + 1 || colonneArrivee == colonneDepart - 1
                    || colonneDepart == colonneArrivee)) || (ligneArrivee == ligneDepart - 1 && (colonneArrivee == colonneDepart + 1
                    || colonneArrivee == colonneDepart - 1 || colonneDepart == colonneArrivee)) || (ligneArrivee == ligneDepart && (colonneArrivee == colonneDepart + 1
                    || colonneArrivee == colonneDepart - 1 ))) {
                if (!caseBlancMenace(plateau, colonneArrivee, ligneArrivee) && plateau[colonneDepart][ligneDepart] % 2 == 0) {
                    return true;
                } else if (!caseNoirMenace(plateau, colonneArrivee, ligneArrivee) && plateau[colonneDepart][ligneDepart] % 2 == 1) {
                    return true;
                } else {
                    return false;
                }
                //return true;
            }
        }
        return false;
    }


    /**
     * convertit la position entrée en un tableau d'entier
     * @param position  de type string
     * @return tableau d'entier de taille 2
     */
    public static int[] convertionPosition(String position) {
        position = position.toLowerCase();
        int colonne = position.charAt(0);
        int ligne = position.charAt(1);
        int[] indicepositionDepart = new int[2];
        indicepositionDepart[0] = colonne - 'a';
        indicepositionDepart[1] = 7 - (Character.getNumericValue(ligne) - 1);
        return indicepositionDepart;
    }

    /**
     * prend la première colonne du tableau d'entier de convertionPosition
     * @param indicepositionDepart
     * @return un entier qui correspond a la colonne de la position
     */
    public static int convertionColonne(int[] indicepositionDepart) {
        int colonne = indicepositionDepart[0];
        return colonne;
    }

    /**
     * prend la deuxième colonne du tableau d'entier de convertionPosition
     * @param indicepositionDepart
     * @return un entier qui correspond a la ligne de la position
     */
    public static int convertionLigne(int[] indicepositionDepart) {
        int ligne = indicepositionDepart[1];
        return ligne;
    }

    //deplace la piece

    /**
     * déplace la pièce et vide la case qu'il a laissé
     * @param plateau
     * @param colonneD  colonne de départ avant le déplacement
     * @param ligneD  ligne de départ avant le déplacement
     * @param colonneA colonne d'arrivée après le déplacement
     * @param ligneA ligne d'arrivée après le déplacement
     * @return le même plateau apres le déplacement
     */
    public static int[][] affichagePieceDeplacement(int[][] plateau, int colonneD, int ligneD, int colonneA, int ligneA) {
        plateau[colonneA][ligneA] = plateau[colonneD][ligneD];
        plateau[colonneD][ligneD] = -1;
        return plateau;
    }


    /**
     * retrouve la position du roi blanc dans le plateau
     * @param plateau
     * @return un tableau d'entier de taille 2 où se trouve la position du roi blanc dans le plateau
     */
    public static int[] positionDuRoiBlanc(int[][] plateau) {
        int colonne = 0;
        int ligne = 0;
        int[] position = new int[2];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (plateau[j][i] == 10) {
                    colonne = j;
                    ligne = i;
                }
            }
        }
        position[0] = colonne;
        position[1] = ligne;
        return position;
    }

    /**
     * retrouve la position du roi blanc dans le plateau
     * @param plateau
     * @return un tableau d'entier de taille 2 où se trouve la position du roi blanc dans le plateau
     */
    public static int[] positionDuRoiNoir(int[][] plateau) {
        int colonne = 0;
        int ligne = 0;
        int[] position = new int[2];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (plateau[j][i] == 11) {
                    colonne = j;
                    ligne = i;
                }
            }
        }
        position[0] = colonne;
        position[1] = ligne;
        return position;
    }

    /**
     * vérifie pour chaque pièce noire si la position d'arrivée après le déplacement est la position du roi blanc
     * @param plateau
     * @param colonneD colonne de départ avant le déplacement
     * @param ligneD ligne de départ avant le déplacement
     * @return vraie si la position d'arrivée après le déplacement est la position du roi blanc / faux sinon
     */
    public static boolean blancEnEchec(int[][] plateau, int colonneD, int ligneD) {
        int colonne = convertionColonne(positionDuRoiBlanc(plateau));
        int ligne = convertionLigne(positionDuRoiBlanc(plateau));
        switch (plateau[colonneD][ligneD]) {
            case 1:
                if (verifMouvPionNoir(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 3:
                if (verifMouvTourNoir(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 5:
                if (verifMouvCavalier(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 7:
                if (verifMouvFou(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 9:
                if (verifMouvReine(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
        /*case 11:
            if (verifMouvRoi(colonneD, ligneD, colonne, ligne, plateau)) {
                return true;
            }
            return false;*/
        }

        return false;
    }

    /**
     * vérifie pour chaque pièce noire si la position d'arrivée après le déplacement est la position du roi noir
     * @param plateau
     * @param colonneD colonne de départ avant le déplacement
     * @param ligneD ligne de départ avant le déplacement
     * @return vraie si la position d'arrivée après le déplacement est la position du roi blanc / faux sinon
     */
    public static boolean noirEnEchec(int[][] plateau, int colonneD, int ligneD) {
        int colonne = convertionColonne(positionDuRoiNoir(plateau));
        int ligne = convertionLigne(positionDuRoiNoir(plateau));
        switch (plateau[colonneD][ligneD]) {
            case 0:
                if (verifMouvPionBlanc(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 2:
                if (verifMouvTourBlanche(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 4:
                if (verifMouvCavalier(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 6:
                if (verifMouvFou(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 8:
                if (verifMouvReine(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
        /*case 10:
            if (verifMouvRoi(colonneD, ligneD, colonne, ligne, plateau)) {
                System.out.println("roi");
                return true;
            }
            return false;*/
        }

        return false;
    }


    /**
     * vérifie la validité de blancEnEchec sur toutes les cases du plateau
     * @param plateau
     * @return vrai si blancEnEchec est vraie soit que le roi Blanc est en echec/ faux sinon
     */
    public static boolean echecBlanc(int[][] plateau) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (blancEnEchec(plateau, j, i)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * vérifie la validité de noirEnEchec sur toutes les cases du plateau
     * @param plateau
     * @return vrai si noirEnEchec est vraie soit que le roi Noir est en echec / faux sinon
     */
    public static boolean echecNoir(int[][] plateau) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (noirEnEchec(plateau, j, i)) {
                    return true;
                }
            }
        }
        return false;
    }

    /** vérifie si le plateau est en état d'echec et mat par les blancs (les noirs en echec)
     * @param plateau
     * @param colonneA colonne d'arrivée du dernier tour
     * @param ligneA ligne d'arrivée du dernier tour
     * @return vraie si le plateau est en echec et mat par les blancs / faux sinon
     */
    public static boolean echecMatParBlanc(int[][] plateau, int colonneA, int ligneA) {
        int cpt = 0;
        if (echecNoir(plateau)) {
            for (int y = -1; y < 2; y++) {
                for (int x = -1; x < 2; x++) {
                    if (!verifMouvRoi(convertionColonne(positionDuRoiNoir(plateau)),
                            convertionLigne(positionDuRoiNoir(plateau)),
                            convertionColonne(positionDuRoiNoir(plateau)) + x,
                            convertionLigne(positionDuRoiNoir(plateau)) + y,
                            plateau)) {
                        cpt++;
                    } else if ((verifMouvRoi(convertionColonne(positionDuRoiNoir(plateau)),
                            convertionLigne(positionDuRoiNoir(plateau)),
                            convertionColonne(positionDuRoiNoir(plateau)) + x,
                            convertionLigne(positionDuRoiNoir(plateau)) + y,
                            plateau)
                            && (caseNoirMenace(plateau,
                            convertionColonne(positionDuRoiNoir(plateau)) + x,
                            convertionLigne(positionDuRoiNoir(plateau)) + y))
                            || caseBlancheProtege(plateau, convertionColonne(positionDuRoiNoir(plateau)) + x,
                            convertionLigne(positionDuRoiNoir(plateau)) + y))) {
                        cpt++;
                    }
                    if (cpt == 9) {
                        if (caseBlancMenace(plateau, colonneA, ligneA)) { //hors roi Blanc
                            return false;
                        } else if (mouvPossibleDunCoupNoirSurLaDiagonnaleDuRoiNoir(plateau, colonneA, ligneA)
                                && (plateau[colonneA][ligneA] == 2 || plateau[colonneA][ligneA] == 6
                                || plateau[colonneA][ligneA] == 8)) {
                            return false;
                        } else {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /** vérifie si le plateau est en état d'echec et mat par les noirs (les blancs en echec)
     * @param plateau
     * @param colonneA colonne d'arrivée du dernier tour
     * @param ligneA ligne d'arrivée du dernier tour
     * @return vraie si le plateau est en echec et mat par les noirs / faux sinon
     */
    public static boolean echecMatParNoir(int[][] plateau, int colonneA, int ligneA) { //mettre exeption sur le roi et reperer automatiquement la piece qui met en echec
        int cpt = 0;
        if (echecBlanc(plateau)) {
            for (int y = -1; y < 2; y++) {
                for (int x = -1; x < 2; x++) {
                    if (!verifMouvRoi(convertionColonne(positionDuRoiBlanc(plateau)),
                            convertionLigne(positionDuRoiBlanc(plateau)),
                            convertionColonne(positionDuRoiBlanc(plateau)) + x,
                            convertionLigne(positionDuRoiBlanc(plateau)) + y,
                            plateau)) {
                        cpt++;
                    } else if ((verifMouvRoi(convertionColonne(positionDuRoiBlanc(plateau)),
                            convertionLigne(positionDuRoiBlanc(plateau)),
                            convertionColonne(positionDuRoiBlanc(plateau)) + x,
                            convertionLigne(positionDuRoiBlanc(plateau)) + y,
                            plateau) && (caseBlancMenace(plateau, convertionColonne(positionDuRoiBlanc(plateau)) + x,
                            convertionLigne(positionDuRoiBlanc(plateau)) + y))
                            || caseNoirProtege(plateau, convertionColonne(positionDuRoiBlanc(plateau)) + x,
                            convertionLigne(positionDuRoiBlanc(plateau)) + y))) {
                        cpt++;
                    }
                    if (cpt == 9) {
                        if (caseNoirMenace(plateau, colonneA, ligneA)) { //hors roi Blanc
                            return false;
                        } else if (mouvPossibleDunCoupBlancSurLaDiagonnaleDuRoiBlanc(plateau, colonneA, ligneA)
                                && (plateau[colonneA][ligneA] == 3 || plateau[colonneA][ligneA] == 7
                                || plateau[colonneA][ligneA] == 9)) {
                            return false;
                        } else {
                            return true;
                        }
                    }
                }
            }
        }
        return false;

    }

    /**
     * vérifie si un mouvement blanc menace une pièce noire
     * @param plateau
     * @param colonneD  colonne de départ avant le déplacement
     * @param ligneD  ligne de départ avant le déplacement
     * @param colonne colonne d'arrivée après le déplacement
     * @param ligne ligne d'arrivée après le déplacement
     * @return vrai si un mouvement blanc menace une pièce noire / faux sinon
     */
    public static boolean caseMenaceParCoupBlanc(int[][] plateau, int colonneD, int ligneD, int colonne, int ligne) {
        switch (plateau[colonneD][ligneD]) {
            case 0:
                if (verifMouvPionBlanc(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 2:
                if (verifMouvTourBlanche(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 4:
                if (verifMouvCavalier(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 6:
                if (verifMouvFou(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 8:
                if (verifMouvReine(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
        }

        return false;
    }

    /**
     *  vérifie si un mouvement noir menace une pièce blanche
     * @param plateau
     * @param colonneD  colonne de départ avant le déplacement
     * @param ligneD  ligne de départ avant le déplacement
     * @param colonne colonne d'arrivée après le déplacement
     * @param ligne ligne d'arrivée après le déplacement
     * @return vrai si un mouvement noir menace une pièce blanche / faux sinon
     */
    public static boolean caseMenaceParCoupNoir(int[][] plateau, int colonneD, int ligneD, int colonne, int ligne) {

        switch (plateau[colonneD][ligneD]) {
            case 1:
                if (verifMouvPionNoir(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 3:
                if (verifMouvTourNoir(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 5:
                if (verifMouvCavalier(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 7:
                if (verifMouvFou(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 9:
                if (verifMouvReine(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
        }

        return false;
    }

    /** vérifie la validité de CaseMenaceParCoupNoir sur toutes les cases du plateau
     * @param plateau
     * @param colonneA colonne d'arrivée après le déplacement
     * @param ligneA ligne d'arrivée après le déplacement
     * @return vrai si CaseBlancMenace est vrai sur une case du plateau au moin / faux sinon
     */
    public static boolean caseBlancMenace(int[][] plateau, int colonneA, int ligneA) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (caseMenaceParCoupNoir(plateau, j, i, colonneA, ligneA)) {
                    return true;
                }
            }
        }
        return false;
    }

    /** vérifie la validité de CaseMenaceParCoupBlanc sur toutes les cases du plateau
     * @param plateau
     * @param colonneA colonne d'arrivée après le déplacement
     * @param ligneA ligne d'arrivée après le déplacement
     * @return vrai si CaseMenaceParCoupBlanc est vrai sur une case du plateau au moin / faux sinon
     */
    public static boolean caseNoirMenace(int[][] plateau, int colonneA, int ligneA) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (caseMenaceParCoupBlanc(plateau, j, i, colonneA, ligneA)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * verifie si un pion blanc est protegé par une pièce du plateau
     * @param colonneDepart colonne de départ avant le déplacement
     * @param ligneDepart ligne de départ avant le déplacement
     * @param colonneArrivee colonne d'arrivée après le déplacement
     * @param ligneArrivee ligne d'arrivée après le déplacement
     * @param plateau
     * @return vrai si un pion blanc est protegé par une pièce du plateau / faux sinon
     */
    public static boolean verifProtectionPionBlanc(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {

        if (verifCaseVide(plateau, colonneArrivee, ligneArrivee) && ligneArrivee == ligneDepart - 1
                && (colonneArrivee == colonneDepart - 1 || colonneArrivee == colonneDepart + 1)
                && verifPosition(colonneArrivee, ligneArrivee)
                && plateau[colonneArrivee][ligneArrivee] % 2 == plateau[colonneDepart][ligneDepart] % 2) {
            return true;
        }

        return false;
    }

    /**
     * verifie si un pion noir est protegé par une pièce du plateau
     * @param colonneDepart colonne de départ avant le déplacement
     * @param ligneDepart ligne de départ avant le déplacement
     * @param colonneArrivee colonne d'arrivée après le déplacement
     * @param ligneArrivee ligne d'arrivée après le déplacement
     * @param plateau
     * @return vrai si un pion noir est protegé par une pièce du plateau / faux sinon
     */
    public static boolean verifProtectionPionNoir(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {

        if (verifCaseVide(plateau, colonneArrivee, ligneArrivee) && ligneArrivee == ligneDepart + 1
                && (colonneArrivee == colonneDepart - 1 || colonneArrivee == colonneDepart + 1)
                && verifPosition(colonneArrivee, ligneArrivee)
                && plateau[colonneArrivee][ligneArrivee] % 2 == plateau[colonneDepart][ligneDepart] % 2) {
            return true;
        }

        return false;
    }


    /**
     * verifie si un tour est protegé par une pièce du plateau
     * @param colonneDepart colonne de départ avant le déplacement
     * @param ligneDepart ligne de départ avant le déplacement
     * @param colonneArrivee colonne d'arrivée après le déplacement
     * @param ligneArrivee ligne d'arrivée après le déplacement
     * @param plateau
     * @return vrai si un tour est protegé par une pièce du plateau / faux sinon
     */
    public static boolean verifProtectionTour(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if ((ligneArrivee == ligneDepart || colonneArrivee == colonneDepart)
                && verifTrajetVide(plateau, colonneDepart, ligneDepart, colonneArrivee, ligneArrivee)
                && verifPosition(colonneArrivee, ligneArrivee)
                && (plateau[colonneArrivee][ligneArrivee] % 2 == plateau[colonneDepart][ligneDepart] % 2)) {
            return true;
        }
        return false;
    }

    /**
     * verifie si un cavalier est protegé par une pièce du plateau
     * @param colonneDepart colonne de départ avant le déplacement
     * @param ligneDepart ligne de départ avant le déplacement
     * @param colonneArrivee colonne d'arrivée après le déplacement
     * @param ligneArrivee ligne d'arrivée après le déplacement
     * @param plateau
     * @return vrai si un cavalier est protegé par une pièce du plateau / faux sinon
     */
    public static boolean verifProtectionCavalier(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if (verifPosition(colonneArrivee, ligneArrivee)
                && (plateau[colonneArrivee][ligneArrivee] % 2 == plateau[colonneDepart][ligneDepart] % 2)
                && ((Math.abs(colonneArrivee - colonneDepart) == 2 && Math.abs(ligneArrivee - ligneDepart) == 1)
                || (Math.abs(colonneArrivee - colonneDepart) == 1 && Math.abs(ligneArrivee - ligneDepart) == 2))) {
            return true;
        }
        return false;
    }

    /**
     * verifie si un fou est protegé par une pièce du plateau
     * @param colonneDepart colonne de départ avant le déplacement
     * @param ligneDepart ligne de départ avant le déplacement
     * @param colonneArrivee colonne d'arrivée après le déplacement
     * @param ligneArrivee ligne d'arrivée après le déplacement
     * @param plateau
     * @return vrai si un fou est protegé par une pièce du plateau / faux sinon
     */
    public static boolean verifProtectionFou(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if (verifPosition(colonneArrivee, ligneArrivee)
                && (plateau[colonneArrivee][ligneArrivee] % 2 == plateau[colonneDepart][ligneDepart] % 2)
                && verifTrajetVide(plateau, colonneDepart, ligneDepart, colonneArrivee, ligneArrivee)) {
            if (Math.abs(ligneArrivee - ligneDepart) == Math.abs(colonneArrivee - colonneDepart)) return true;
        }
        return false;
    }

    /**
     * verifie si une reine est protegé par une pièce du plateau
     * @param colonneDepart colonne de départ avant le déplacement
     * @param ligneDepart ligne de départ avant le déplacement
     * @param colonneArrivee colonne d'arrivée après le déplacement
     * @param ligneArrivee ligne d'arrivée après le déplacement
     * @param plateau
     * @return vrai si une reine est protegé par une pièce du plateau / faux sinon
     */
    public static boolean verifProtectionReine(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if (verifPosition(colonneArrivee, ligneArrivee)
                && (plateau[colonneArrivee][ligneArrivee] % 2 == plateau[colonneDepart][ligneDepart] % 2)
                && verifTrajetVide(plateau, colonneDepart, ligneDepart, colonneArrivee, ligneArrivee)) {
            if ((ligneArrivee == ligneDepart || colonneArrivee == colonneDepart)
                    || Math.abs(ligneArrivee - ligneDepart) == Math.abs(colonneArrivee - colonneDepart)) {
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * verifie si un roi est protegé par une pièce du plateau
     * @param colonneDepart colonne de départ avant le déplacement
     * @param ligneDepart ligne de départ avant le déplacement
     * @param colonneArrivee colonne d'arrivée après le déplacement
     * @param ligneArrivee ligne d'arrivée après le déplacement
     * @param plateau
     * @return vrai si un roi est protegé par une pièce du plateau / faux sinon
     */
    public static boolean verifProtectionRoi(int colonneDepart, int ligneDepart, int colonneArrivee, int ligneArrivee, int[][] plateau) {
        if (verifPosition(colonneArrivee, ligneArrivee) && (plateau[colonneArrivee][ligneArrivee] % 2 == plateau[colonneDepart][ligneDepart] % 2)) {
            if ((ligneArrivee == ligneDepart + 1 && (colonneArrivee == colonneDepart + 1 || colonneArrivee == colonneDepart - 1))
                    || (ligneArrivee == ligneDepart - 1 && (colonneArrivee == colonneDepart + 1
                    || colonneArrivee == colonneDepart - 1 || colonneArrivee == colonneDepart))
                    || (ligneArrivee == ligneDepart && (colonneArrivee == colonneDepart + 1 || colonneArrivee == colonneDepart - 1))) {
                return true;
            }
        }
        return false;
    }

    /**
     * vérifie si une pièce noir protège une pièce noir
     * @param plateau
     * @param colonneD colonne de départ avant le déplacement
     * @param ligneD ligne de départ avant le déplacement
     * @param colonne colonne d'arrivée après le déplacement
     * @param ligne ligne d'arrivée après le déplacement
     * @return vrai si une pièce noir protège une pièce noir / faux sinon
     */
    public static boolean caseProtegeParCoupNoir(int[][] plateau, int colonneD, int ligneD, int colonne, int ligne) {

        switch (plateau[colonneD][ligneD]) {
            case 1:
                if (verifProtectionPionNoir(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 3:
                if (verifProtectionTour(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 5:
                if (verifProtectionCavalier(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 7:
                if (verifProtectionFou(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 9:
                if (verifProtectionReine(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 11:
                if (verifProtectionRoi(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
        }

        return false;
    }

    /**
     * vérifie si une pièce blanche protège une pièce blanche
     * @param plateau
     * @param colonneD  colonne de départ avant le déplacement
     * @param ligneD  ligne de départ avant le déplacement
     * @param colonne colonne d'arrivée après le déplacement
     * @param ligne ligne d'arrivée après le déplacement
     * @return vrai si une pièce blanche protège une pièce blanche / faux sinon
     */
    public static boolean caseProtegeParCoupBlanc(int[][] plateau, int colonneD, int ligneD, int colonne, int ligne) {
        switch (plateau[colonneD][ligneD]) {
            case 0:
                if (verifProtectionPionBlanc(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 2:
                if (verifProtectionTour(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 4:
                if (verifProtectionCavalier(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 6:
                if (verifProtectionFou(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 8:
                if (verifProtectionReine(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
            case 10:
                if (verifProtectionRoi(colonneD, ligneD, colonne, ligne, plateau)) {
                    return true;
                }
                return false;
        }

        return false;
    }

    /**
     *
     * @param plateau
     * @param colonneA
     * @param ligneA
     * @return
     */
    public static boolean caseNoirProtege(int[][] plateau, int colonneA, int ligneA) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (caseProtegeParCoupNoir(plateau, j, i, colonneA, ligneA)) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     *
     * @param plateau
     * @param colonneA
     * @param ligneA
     * @return
     */
    public static boolean caseBlancheProtege(int[][] plateau, int colonneA, int ligneA) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (caseProtegeParCoupBlanc(plateau, j, i, colonneA, ligneA)) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * vérifie si un mouvement blanc est possible sur une des diagonales du roi blanc
     * @param plateau
     * @param colonneD colonne de départ avant le déplacement
     * @param ligneD ligne de départ avant le déplacement
     * @return vrai si un mouvement blanc est possible sur une des diagonales du roi blanc / faux sinon
     */
    public static boolean mouvPossibleDunCoupBlancSurLaDiagonnaleDuRoiBlanc(int[][] plateau, int colonneD, int ligneD) {
        int colonne = convertionColonne(positionDuRoiBlanc(plateau));
        int ligne = convertionLigne(positionDuRoiBlanc(plateau));
        List<int[]> trajet = trajetCoordonnees(plateau, colonne, ligne, colonneD, ligneD);
        for (int[] coord : trajet) {
            if (caseNoirMenace(plateau, coord[1], coord[0])) {
                return true;
            }

        }
        return false;

    }

    /**
     * vérifie si un mouvement noir est possible sur une des diagonales du roi noir
     * @param plateau
     * @param colonneD colonne de départ avant le déplacement
     * @param ligneD ligne de départ avant le déplacement
     * @return vrai si un mouvement noir est possible sur une des diagonales du roi noir / faux sinon
     */
    public static boolean mouvPossibleDunCoupNoirSurLaDiagonnaleDuRoiNoir(int[][] plateau, int colonneD, int ligneD) {
        int colonne = convertionColonne(positionDuRoiNoir(plateau));
        int ligne = convertionLigne(positionDuRoiNoir(plateau));
        List<int[]> trajet = trajetCoordonnees(plateau, colonne, ligne, colonneD, ligneD);
        for (int[] coord : trajet) {
            if (caseBlancMenace(plateau, coord[1], coord[0])) {
                return true;
            }

        }
        return false;

    }

    /**
     * vérifie si le plateau est en état de petit roque blanc
     * @param plateau
     * @return vrai si le plateau est en état de petit roque blanc / faux sinon
     */
    public static boolean verifPetitRoqueRoiBlanc(int[][] plateau) {
        // Vérification des conditions pour le roque du côté du roi
        int[] positionRoiBlanc = positionDuRoiBlanc(plateau);
        int colonneRoi = positionRoiBlanc[0];
        int ligneRoi = positionRoiBlanc[1];

        // Le roi doit être sur sa case initiale (case 4 de la ligne 0)
        if (colonneRoi != 4 || ligneRoi != 7) {
            return false; // Le roi a déjà bougé
        }

        // Vérification que le roi et la tour n'ont pas bougé
        if (plateau[4][7] != 10 || plateau[7][7] != 2) {
            return false; // Le roi et la tour doivent être en place
        }

        // Vérification que les cases entre le roi et la tour sont vides
        for (int i = 5; i < 7; i++) {
            if (!verifCaseVide(plateau, i, 7)) {
                return false; // Il y a une pièce entre le roi et la tour
            }
        }

        // Vérification que le roi n'est pas en échec avant de faire le roque
        if (caseBlancMenace(plateau, 5, 7) || caseBlancMenace(plateau, 6, 7)) {
            return false; // Les cases sont menacées
        }

        // Vérification que le roi ne traverse pas une case attaquée (pas d'échec)
        if (caseBlancMenace(plateau, 4, 7) || caseBlancMenace(plateau, 5, 7)
                || caseBlancMenace(plateau, 6, 7)) {
            return false; // Le roi ne doit pas traverser une case attaquée
        }

        return true;
    }

    /**
     * vérifie si le plateau est en état de petit roque noir
     * @param plateau
     * @return vrai si le plateau est en état de petit roque noir / faux sinon
     */
    public static boolean verifPetitRoqueRoiNoir(int[][] plateau) {
        // Vérification des conditions pour le roque du côté du roi
        int[] positionRoiNoir = positionDuRoiNoir(plateau);
        int colonneRoi = positionRoiNoir[0];
        int ligneRoi = positionRoiNoir[1];

        // Le roi doit être sur sa case initiale (case 4 de la ligne 0)
        if (colonneRoi != 4 || ligneRoi != 0) {
            return false; // Le roi a déjà bougé
        }

        // Vérification que le roi et la tour n'ont pas bougé
        if (plateau[4][0] != 11 || plateau[7][0] != 3) {
            return false; // Le roi et la tour doivent être en place
        }

        // Vérification que les cases entre le roi et la tour sont vides
        for (int i = 5; i < 7; i++) {
            if (!verifCaseVide(plateau, i, 0)) {
                return false; // Il y a une pièce entre le roi et la tour
            }
        }

        // Vérification que le roi n'est pas en échec avant de faire le roque
        if (caseNoirMenace(plateau, 4, 0) || caseNoirMenace(plateau, 5, 0)) {
            return false; // Les cases sont menacées
        }

        // Vérification que le roi ne traverse pas une case attaquée (pas d'échec)
        if (caseNoirMenace(plateau, 4, 0) || caseNoirMenace(plateau, 5, 0)
                || caseNoirMenace(plateau, 6, 0)) {
            return false; // Le roi ne doit pas traverser une case attaquée
        }
        return true;
    }

    /**
     *vérifie si le plateau est en état de grand roque blanc
     * @param plateau
     * @return vrai si le plateau est en état de grand roque blanc / faux sinon
     */
    public static boolean verifGrandRoqueRoiBlanc(int[][] plateau) {
        // Vérification des conditions pour le roque du côté du roi
        int[] positionRoiBlanc = positionDuRoiBlanc(plateau);
        int colonneRoi = positionRoiBlanc[0];
        int ligneRoi = positionRoiBlanc[1];

        // Le roi doit être sur sa case initiale (case 4 de la ligne 0)
        if (colonneRoi != 4 || ligneRoi != 7) {
            return false; // Le roi a déjà bougé
        }

        // Vérification que le roi et la tour n'ont pas bougé
        if (plateau[4][7] != 10 || plateau[0][7] != 2) {
            return false; // Le roi et la tour doivent être en place
        }

        // Vérification que les cases entre le roi et la tour sont vides
        for (int i = 1; i < 4; i++) {
            if (!verifCaseVide(plateau, i, 7)) {
                return false; // Il y a une pièce entre le roi et la tour
            }
        }

        // Vérification que le roi n'est pas en échec avant de faire le roque
        if (caseBlancMenace(plateau, 5, 7) || caseBlancMenace(plateau, 6, 7)) {
            return false; // Les cases sont menacées
        }

        // Vérification que le roi ne traverse pas une case attaquée (pas d'échec)
        if (caseBlancMenace(plateau, 1, 7) || caseBlancMenace(plateau, 2, 7)
                || caseBlancMenace(plateau, 3, 7) || caseBlancMenace(plateau, 4, 7)) {
            return false; // Le roi ne doit pas traverser une case attaquée
        }
        return true;
    }

    /**
     *vérifie si le plateau est en état de grand roque noir
     * @param plateau
     * @return vrai si le plateau est en état de grand roque noir / faux sinon
     */
    public static boolean verifGrandRoqueRoiNoir(int[][] plateau) {
        // Vérification des conditions pour le roque du côté du roi
        int[] positionRoiNoir = positionDuRoiNoir(plateau);
        int colonneRoi = positionRoiNoir[0];
        int ligneRoi = positionRoiNoir[1];

        // Le roi doit être sur sa case initiale (case 4 de la ligne 0)
        if (colonneRoi != 4 || ligneRoi != 0) {
            return false; // Le roi a déjà bougé
        }

        // Vérification que le roi et la tour n'ont pas bougé
        if (plateau[4][0] != 11 || plateau[0][0] != 3) {
            return false; // Le roi et la tour doivent être en place
        }

        // Vérification que les cases entre le roi et la tour sont vides
        for (int i = 1; i < 4; i++) {
            if (!verifCaseVide(plateau, i, 0)) {
                return false; // Il y a une pièce entre le roi et la tour
            }
        }

        // Vérification que le roi n'est pas en échec avant de faire le roque
        if (caseNoirMenace(plateau, 5, 0) || caseNoirMenace(plateau, 6, 0)) {
            return false; // Les cases sont menacées
        }

        // Vérification que le roi ne traverse pas une case attaquée (pas d'échec)
        if (caseNoirMenace(plateau, 1, 0) || caseNoirMenace(plateau, 2, 0)
                || caseNoirMenace(plateau, 3, 0) || caseBlancMenace(plateau, 4, 0)) {
            return false; // Le roi ne doit pas traverser une case attaquée
        }
        return true;
    }

    /**
     * verifie si la promotion d'un pion blanc est possible
     * @param plateau
     * @return vrai si la promotion d'un pion blanc est possible / faux sinon
     */
    public static boolean promotionBlanc(int[][] plateau) {
        for (int colonne = 0; colonne < 8; colonne++) {
            if (plateau[colonne][0] == 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * verifie si la promotion d'un pion noir est possible
     * @param plateau
     * @return vrai si la promotion d'un pion noir est possible / faux sinon
     */
    public static boolean promotionNoir(int[][] plateau) {
        for (int colonne = 0; colonne < 8; colonne++) {
            if (plateau[colonne][7] == 1) {
                return true;
            }
        }
        return false;
    }

    /**
     * affiche la promotion du pion noir en une pièce choisi par la saisie
     * @param plateau
     * @param colonneA colonne d'arrivée après le déplacement
     * @param ligneA ligne d'arrivée après le déplacement
     * @return le plateau après la promotion du pion
     */
    public static int[][] promotionNoirAffichage(int[][] plateau, int colonneA, int ligneA) {
        if (DeplacementPiece.promotionNoir(plateau)) {
            System.out.println("Promotion ! Choisissez une pièce :");
            System.out.println("1. Dame");
            System.out.println("2. Cavalier");
            System.out.println("3. Tour");
            System.out.println("4. Fou");

            Scanner sc = new Scanner(System.in).useDelimiter("\n");
            int choix = sc.nextInt();
            switch (choix) {
                case 1:
                    System.out.println("Pion promu en Dame!");
                    plateau[colonneA][ligneA] = 9;
                    Plateau.affichePlateau(plateau);
                    break;
                case 2:
                    System.out.println("Pion promu en Cavalier!");
                    plateau[colonneA][ligneA] = 5;
                    Plateau.affichePlateau(plateau);
                    break;
                case 3:
                    System.out.println("Pion promu en Tour!");
                    plateau[colonneA][ligneA] = 3;
                    Plateau.affichePlateau(plateau);
                    break;
                case 4:
                    System.out.println("Pion promu en Fou!");
                    plateau[colonneA][ligneA] = 7;
                    Plateau.affichePlateau(plateau);
                    break;
                default:
                    System.out.println("Choix invalide, promotion par défaut en Dame.");
            }
        }
        return plateau;
    }

    /**
     * affiche la promotion du pion blanc en une pièce choisi par la saisie
     * @param plateau
     * @param colonneA colonne d'arrivée après le déplacement
     * @param ligneA ligne d'arrivée après le déplacement
     * @return le plateau après la promotion du pion
     */
    public static int[][] promotionBlancAffichage(int[][] plateau, int colonneA, int ligneA) {
        if (DeplacementPiece.promotionBlanc(plateau)) {
            System.out.println("Promotion ! Choisissez une pièce :");
            System.out.println("1. Dame");
            System.out.println("2. Cavalier");
            System.out.println("3. Tour");
            System.out.println("4. Fou");
            Scanner sc = new Scanner(System.in).useDelimiter("\n");
            int choix = sc.nextInt();
            switch (choix) {
                case 1:
                    System.out.println("Pion promu en Dame!");
                    plateau[colonneA][ligneA] = 8;
                    Plateau.affichePlateau(plateau);
                    break;
                case 2:
                    System.out.println("Pion promu en Cavalier!");
                    plateau[colonneA][ligneA] = 4;
                    Plateau.affichePlateau(plateau);
                    break;
                case 3:
                    System.out.println("Pion promu en Tour!");
                    plateau[colonneA][ligneA] = 2;
                    Plateau.affichePlateau(plateau);
                    break;
                case 4:
                    System.out.println("Pion promu en Fou!");
                    plateau[colonneA][ligneA] = 6;
                    Plateau.affichePlateau(plateau);
                    break;
                default:
                    System.out.println("Choix invalide, promotion par défaut en Dame.");
                    break;
            }
        }
        return plateau;
    }
}
