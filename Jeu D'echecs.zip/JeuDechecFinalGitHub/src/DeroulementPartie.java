import java.util.Scanner;
public class DeroulementPartie {
    public static void deroulementPartieJoueur() {
        Scanner sc = new Scanner(System.in);
        int[][] plateau = Plateau.remplissagetableau(Plateau.plateauvide());
        boolean partie = false;
        int colonneD, ligneD, colonneA, ligneA;
        String positionD, positionA;
        int compteurcoup = 0;
        String pseudo1, pseudo2;
        System.out.println("Joueur 1, veuillez entrez votre pseudo:");
        pseudo1 = sc.nextLine();
        System.out.println("Joueur 2, veuillez entrez votre pseudo:");
        pseudo2 = sc.nextLine();
        Plateau.affichePlateau(plateau);
        while (!partie) {
            if (compteurcoup % 2 == 0) System.out.println(pseudo1 + ", veuillez entrez la position de votre pièce : ");
            else System.out.println(pseudo2 + ", veuillez entrez la position de votre pièce : ");
            positionD = sc.nextLine().toLowerCase();
            while (true) {
                if (positionD.length() == 2 &&
                        positionD.charAt(0) >= 'a' && positionD.charAt(0) <= 'h' &&
                        positionD.charAt(1) >= '1' && positionD.charAt(1) <= '8') {
                    break;
                } else
                    System.out.println("Position invalide ! Veuillez entrer la position de votre pièce (sous la forme a1, h7...).");
                positionD = sc.nextLine().toLowerCase();
            }
            colonneD = DeplacementPiece.convertionColonne(DeplacementPiece.convertionPosition(positionD));
            ligneD =DeplacementPiece.convertionLigne(DeplacementPiece.convertionPosition(positionD));
            if (DeplacementPiece.verifPosition(colonneD, ligneD) && compteurcoup % 2 == plateau[colonneD][ligneD] % 2) { //verif si piece est jouable en fct de la couleur
                if (compteurcoup % 2 == 0)
                    System.out.println(pseudo1 + ", veuillez entrez position d'arrivée que vous souhaitez : ");
                else System.out.println(pseudo2 + ", veuillez entrez position d'arrivée que vous souhaitez : ");
                positionA = sc.nextLine().toLowerCase();
                while (true) {
                    if (positionA.length() == 2 &&
                            positionA.charAt(0) >= 'a' && positionA.charAt(0) <= 'h' &&
                            positionA.charAt(1) >= '1' && positionA.charAt(1) <= '8') {
                        break;
                    } else
                        System.out.println("Position invalide ! la position de votre pièce (sous la forme a3, h5...)");
                    positionA = sc.nextLine().toLowerCase();
                }
                colonneA = DeplacementPiece.convertionColonne(DeplacementPiece.convertionPosition(positionA));
                ligneA = DeplacementPiece.convertionLigne(DeplacementPiece.convertionPosition(positionA));
                int revientpiece = plateau[colonneA][ligneA];
                switch (plateau[colonneD][ligneD]) {
                    case 0: //PIONT BLANC
                        if (DeplacementPiece.verifMouvPionBlanc(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            if (DeplacementPiece.echecBlanc(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                            compteurcoup++;
                            if (DeplacementPiece.promotionBlanc(plateau)) {
                                plateau = DeplacementPiece.promotionBlancAffichage(plateau, colonneA, ligneA);
                            }

                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 1: //PIONT NOIR
                        if (DeplacementPiece.verifMouvPionNoir(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            if (DeplacementPiece.echecNoir(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                            compteurcoup++;
                            if (DeplacementPiece.promotionNoir(plateau)) {
                                plateau = DeplacementPiece.promotionNoirAffichage(plateau, colonneA, ligneA);
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 2://TOUR BLANCHE
                        if (DeplacementPiece.verifMouvTourBlanche(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecBlanc(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 3://TOUR NOIR
                        if (DeplacementPiece.verifMouvTourNoir(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecNoir(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 4://cavalier blanc
                        if (DeplacementPiece.verifMouvCavalier(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecBlanc(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 5://cavalier NOIR
                        if (DeplacementPiece.verifMouvCavalier(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecNoir(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 6://FOU BLANC
                        if (DeplacementPiece.verifMouvFou(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecBlanc(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 7://FOU NOIR
                        if (DeplacementPiece.verifMouvFou(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecNoir(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 8://REINE BLANCHE
                        if (DeplacementPiece.verifMouvReine(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecBlanc(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 9://REINE NOIR
                        if (DeplacementPiece.verifMouvReine(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecNoir(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else System.out.println("Le déplacement est impossible!");
                        break;
                    case 10://ROI BLANC
                        if (DeplacementPiece.verifMouvRoi(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecBlanc(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else if (!DeplacementPiece.verifMouvRoi(colonneD, ligneD, colonneA, ligneA, plateau)
                                && (DeplacementPiece.verifPetitRoqueRoiNoir(plateau) && colonneD == 4 && ligneD == 0 && colonneA == 6 && ligneA == 0)
                                && (DeplacementPiece.verifGrandRoqueRoiNoir(plateau) && colonneD == 4 && ligneD == 0 && colonneA == 2 && ligneA == 0)) {
                            System.out.println("Le déplacement est impossible!");
                        }
                        if (DeplacementPiece.verifPetitRoqueRoiBlanc(plateau) && colonneD == 4 && ligneD == 7 && colonneA == 6 && ligneA == 7) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, 7, 7, 5, 7);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecBlanc(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        }
                        if (DeplacementPiece.verifGrandRoqueRoiBlanc(plateau) && colonneD == 4 && ligneD == 7 && colonneA == 2 && ligneA == 7) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, 0, 7, 3, 7);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecBlanc(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        }
                        break;
                    case 11://ROI NOIR
                        if (DeplacementPiece.verifMouvRoi(colonneD, ligneD, colonneA, ligneA, plateau)) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecNoir(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        } else if (!DeplacementPiece.verifMouvRoi(colonneD, ligneD, colonneA, ligneA, plateau)
                                && (DeplacementPiece.verifPetitRoqueRoiNoir(plateau) && colonneD == 4 && ligneD == 0 && colonneA == 6 && ligneA == 0)
                                && (DeplacementPiece.verifGrandRoqueRoiNoir(plateau) && colonneD == 4 && ligneD == 0 && colonneA == 2 && ligneA == 0)) {
                            System.out.println("Le déplacement est impossible!");
                        }
                        if (DeplacementPiece.verifPetitRoqueRoiNoir(plateau) && colonneD == 4 && ligneD == 0 && colonneA == 6 && ligneA == 0) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, 7, 0, 5, 0);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecNoir(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        }
                        if (DeplacementPiece.verifGrandRoqueRoiNoir(plateau) && colonneD == 4 && ligneD == 0 && colonneA == 2 && ligneA == 0) {
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneD, ligneD, colonneA, ligneA);
                            plateau = DeplacementPiece.affichagePieceDeplacement(plateau, 0, 0, 3, 0);
                            Plateau.affichePlateau(plateau);
                            compteurcoup++;
                            if (DeplacementPiece.echecNoir(plateau)) {
                                plateau = DeplacementPiece.affichagePieceDeplacement(plateau, colonneA, ligneA, colonneD, ligneD);
                                plateau[colonneA][ligneA] = revientpiece;
                                System.out.println("Déplacement impossible (mise en échec)!");
                                Plateau.affichePlateau(plateau);
                                compteurcoup--;
                            }
                        }
                        break;

                }

                if (DeplacementPiece.echecBlanc(plateau) || DeplacementPiece.echecNoir(plateau)) {
                    if (DeplacementPiece.echecMatParBlanc(plateau, colonneA, ligneA) || DeplacementPiece.echecMatParNoir(plateau, colonneA, ligneA)) {
                        if (DeplacementPiece.echecMatParBlanc(plateau, colonneA, ligneA)) {
                            System.out.println("Echec Et Mat");
                            MenuLancementDuJeu.afficherFinDePartieEchec(pseudo1);
                        }
                        if (DeplacementPiece.echecMatParNoir(plateau, colonneA, ligneA)) {
                            System.out.println("Echec Et Mat");
                            MenuLancementDuJeu.afficherFinDePartieEchec(pseudo2);
                        }
                        partie = true;
                    } else System.out.println("Echec au Roi");
                }
            }else if (DeplacementPiece.verifPosition(colonneD, ligneD) && compteurcoup % 2 != plateau[colonneD][ligneD] % 2 && plateau[colonneD][ligneD] != -1) {
                System.out.println("Ce n'est pas votre pièce!");
                Plateau.affichePlateau(plateau);
            } else {
                System.out.println("Position invalide");
                Plateau.affichePlateau(plateau);
            }
        }
    }
}