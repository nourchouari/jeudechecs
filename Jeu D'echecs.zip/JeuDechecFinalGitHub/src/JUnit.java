import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;

public class JUnit {

    @Test
    public void testVerifMouvPionNoir() {

        int[][] plateau = {
                {1, -1, -1, -1, -1, -1, -1, -1},
                {-1, 1, -1, 0, -1, 3, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {0, -1, 0, -1, 0, -1, 0, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };

        // Mouvement simple vers une case vide
        assertTrue(DeplacementPiece.verifMouvPionNoir(0, 1, 0, 2, plateau));

        // Mouvement initial de deux cases
        assertTrue(DeplacementPiece.verifMouvPionNoir(0, 1, 0, 2, plateau));

        // Mouvement de capture sur une case occupée par une pièce adverse
        plateau[4][2] = 0; // Pion blanc en diagonale
        assertTrue(DeplacementPiece.verifMouvPionNoir(3, 1, 4, 2, plateau));

        // Mouvement invalide sur une case non vide sans capture
        plateau[3][2] = 1; // Case devant le pion noir
        assertFalse(DeplacementPiece.verifMouvPionNoir(3, 1, 3, 2, plateau));

        // Additional tests
        assertFalse(DeplacementPiece.verifMouvPionNoir(3, 1, 3, 0, plateau)); // Mouvement en arrière
        assertFalse(DeplacementPiece.verifMouvPionNoir(3, 1, 4, 1, plateau)); // Mouvement latéral
        plateau[3][2] = -1; // Case devant vide à nouveau
        assertTrue(DeplacementPiece.verifMouvPionNoir(3, 1, 3, 2, plateau)); // Valide après libération
    }


    @Test
    public void testVerifMouvTourNoir() {
        int[][] plateau = {
                {3, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };
        assertTrue(DeplacementPiece.verifMouvTourNoir(0,0,7,0, plateau));
        assertTrue(DeplacementPiece.verifMouvTourNoir(0,0,0,7, plateau));
        int[][] plateau2 = {
                {3, -1, -1, -1, -1, 1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };
        assertFalse(DeplacementPiece.verifMouvTourNoir(0,0,7,0, plateau2));
        assertFalse(DeplacementPiece.verifMouvTourNoir(0,0,0,7, plateau2));
    }


    //
    @Test
    public void convertionPositionTest() {

        // Test de positions valides en minuscules
        assertArrayEquals(new int[]{0, 7}, DeplacementPiece.convertionPosition("a1"), "Conversion de a1 incorrecte");
        assertArrayEquals(new int[]{7, 0}, DeplacementPiece.convertionPosition("h8"), "Conversion de h8 incorrecte");
        assertArrayEquals(new int[]{3, 4}, DeplacementPiece.convertionPosition("d4"), "Conversion de d4 incorrecte");

        // Test de positions valides en majuscules
        assertArrayEquals(new int[]{0, 7}, DeplacementPiece.convertionPosition("A1"), "Conversion de A1 incorrecte");
        assertArrayEquals(new int[]{7, 0}, DeplacementPiece.convertionPosition("H8"), "Conversion de H8 incorrecte");
        assertArrayEquals(new int[]{3, 4}, DeplacementPiece.convertionPosition("D4"), "Conversion de D4 incorrecte");

        // Test de positions intermédiaires
        assertArrayEquals(new int[]{4, 3}, DeplacementPiece.convertionPosition("e5"), "Conversion de e5 incorrecte");
        assertArrayEquals(new int[]{4, 3}, DeplacementPiece.convertionPosition("E5"), "Conversion de E5 incorrecte");

        // Test des bords valides
        assertArrayEquals(new int[]{0, 0}, DeplacementPiece.convertionPosition("a8"), "Conversion de a8 incorrecte");
        assertArrayEquals(new int[]{7, 7}, DeplacementPiece.convertionPosition("h1"), "Conversion de h1 incorrecte");
    }

    @Test
    public void testVerifPosition() {
        assertTrue(DeplacementPiece.verifPosition(0, 0));
        assertTrue(DeplacementPiece.verifPosition(7, 7));
        assertFalse(DeplacementPiece.verifPosition(-1, 0));
        assertFalse(DeplacementPiece.verifPosition(8, 0));
        assertFalse(DeplacementPiece.verifPosition(0, -1));
        assertFalse(DeplacementPiece.verifPosition(0, 8));

        // Additional edge cases
        assertTrue(DeplacementPiece.verifPosition(0, 7)); // Top-left corner
        assertTrue(DeplacementPiece.verifPosition(7, 0)); // Bottom-right corner
    }
    //

    @Test
    public void testVerifCaseVide() {
        // Initialisation d'un plateau d'échecs
        // Les pièces sont représentées par les valeurs données dans le commentaire
        // casevide = 100
        int[][] plateau = {
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, 1, -1, 2, -1, 3, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {0, -1, 0, -1, 0, -1, 0, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };

        // Test des cases vides
        assertTrue(DeplacementPiece.verifCaseVide(plateau, 0, 0), "La case (0,0) est vide");
        assertTrue(DeplacementPiece.verifCaseVide(plateau, 4, 4), "La case (4,4) est vide");
        assertTrue(DeplacementPiece.verifCaseVide(plateau, 7, 7), "La case (7,7) est vide");

        // Test des cases occupées
        assertFalse(DeplacementPiece.verifCaseVide(plateau, 1, 1), "La case (1,1) est occupée");
        assertFalse(DeplacementPiece.verifCaseVide(plateau, 3, 2), "La case (3,2) est occupée");
        assertFalse(DeplacementPiece.verifCaseVide(plateau, 5, 0), "La case (5,0) est occupée");
    }



    @Test
    public void testPromotionBlanc() {
        int[][] plateau = new int[8][8];
        for (int ligne = 0; ligne < 8; ligne++) {
            for (int colonne = 0; colonne < 8; colonne++) {
                plateau[colonne][ligne] = -1;
            }
        }

        plateau[0][0] = -1;
        assertFalse(DeplacementPiece.promotionBlanc(plateau), "Pas de PromotionBlanc");

        plateau[0][0] = 0;
        assertTrue(DeplacementPiece.promotionBlanc(plateau), "PromotionBlanc");
    }

    @Test
    public void testEchecNoir() {
        int[][] plateau = {
                {-1, -1, 7, 2, -1, -1, 4, 11},
                {-1, -1, 2, -1, -1, -1, -1, 1},
                {-1, -1, -1, -1, -1, -1, 1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };

        assertFalse(DeplacementPiece.echecNoir(plateau), "Echec noir");

        int[][] plateau2 = {
                {2, -1, -1, -1, -1, -1, -1, 11},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, 5, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };

        assertTrue(DeplacementPiece.echecNoir(plateau2), "Echec noir");

    }

    @Test
    public void testEchecEtMatNoir() {

        int[][] plateau = {
                {-1, -1, -1, 11, -1, 8, -1, -1},
                {-1, 8, -1, -1, -1, -1, -1, -1},
                {-1, -1, 4, -1, -1, -1, 6, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };

        assertTrue(DeplacementPiece.echecMatParBlanc(plateau, 5, 0));

        int[][] plateau2 = {
                {8, -1, -1, -1, -1, -1, -1, 11},
                {-1, 8, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, 9, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };

        assertFalse(DeplacementPiece.echecMatParBlanc(plateau2, 0, 0));

        int[][] plateau3 = {
                {-1, -1, 7, -1, -1, 2, -1, 11},
                {-1, -1, 2, -1, -1, -1, -1, 1},
                {-1, -1, -1, -1, -1, 5, 1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, 6, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1}
        };

        assertTrue(DeplacementPiece.echecMatParBlanc(plateau3,5,0), "Echec et mat noir");


    }


    @Test
    public void mouvpossibledigonaleroinoir() {
        int[][] plateau = {
                {2, -1, -1, -1, -1, -1, -1, 11},
                {2, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, 5, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
                {-1, -1, -1, -1, -1, -1, -1, -1},
        };

        assertTrue(DeplacementPiece.mouvPossibleDunCoupNoirSurLaDiagonnaleDuRoiNoir(plateau, 0,0));
    }

}